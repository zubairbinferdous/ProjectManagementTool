
<?php $__env->startSection('userContent'); ?>
    <!-- =============== Design & Develop By = MJ MARAZ   ====================== -->

    
    <!-- =======  Data-Table  = Start  ========================== -->
    
    <!-- =======  Data-Table  = End  ===================== -->
    <!-- ============ Java Script Files  ================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\laragon\www\PMS\resources\views/user/allUserData.blade.php ENDPATH**/ ?>