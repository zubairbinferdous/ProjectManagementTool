
<?php $__env->startSection('userContent'); ?>
    <div class="container">
        <div class="row">
            <!-- User Sidebar -->

            <!--/ User Sidebar -->

            <!-- User Content -->
            <div class="col-xl-12 col-lg-12 col-md-12 order-0 order-md-1">

                <div class="row">
                    <h1 class="text-center bold-taxt " style="padding-bottom:.5%"> <?php echo e($ViewProjectData->ProjectName); ?></h1>
                    <div class="card-body">
                        <p class="ProjectDescription" style="padding-bottom:.5%"><?php echo e($ViewProjectData->ProjectDescription); ?>

                        </p>
                    </div>
                    <div class="col-md-6">

                        <div class="card-body">
                            
                            <div class="info-container">
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <span class="fw-semibold me-1">Project Start Date:</span>
                                        <span> <?php echo e($ViewProjectData->ProjectStart); ?> </span>
                                    </li>
                                    <li class="mb-2 pt-1">
                                        <span class="fw-semibold me-1">Project Status:</span>
                                        <span><?php echo e($ViewProjectData->status); ?></span>
                                    </li>
                                    <li class="mb-2 pt-1">
                                        <span class="fw-semibold me-1">Project Capacity:</span>
                                        <span class=" "><?php echo e($ViewProjectData->TotalCapacity); ?></span>
                                    </li>
                                    <li class="mb-2 pt-1">
                                        <span class="fw-semibold me-1">Current Working :</span>
                                        <span class=" "><?php echo e($ViewProjectData->CurrentWorking); ?></span>
                                    </li>
                                    
                                    
                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body">

                            
                            <div class="info-container">
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <span class="fw-semibold me-1">Project Divisions :</span>
                                        <span><?php echo e($ViewProjectData->ProjectDivisions); ?></span>
                                    </li>
                                    <li class="mb-2">
                                        <span class="fw-semibold me-1">Project Districts :</span>
                                        <span><?php echo e($ViewProjectData->ProjectDistricts); ?></span>
                                    </li>
                                    <li class="mb-2">
                                        <span class="fw-semibold me-1">Project Upazilas :</span>
                                        <span><?php echo e($ViewProjectData->ProjectUpazilas); ?></span>
                                    </li>


                                </ul>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Invoice table -->
                <div class="card mb-4">
                    <div class="row">
                        <div class="col-12">
                            <div class="data_table">
                                <table id="example" class="table table-striped table-bordered">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Name</th>
                                            <th>Phone Number</th>
                                            <th>Designation</th>
                                            <th>Project Name</th>
                                            <th>Last Month Payment</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $EmployeeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><a
                                                        href="<?php echo e(route('viewEmployee', $item->id)); ?>"><?php echo e($item->EmployeeName); ?></a>
                                                </td>
                                                <td><?php echo e($item->PhoneNumber); ?></td>
                                                <td><?php echo e($item->Designation); ?></td>
                                                <td><?php echo e($item->projectData->ProjectName); ?></td>
                                                

                                                <?php if($item->status === 'Active'): ?>
                                                    <td class=""><span class="badge bg-label-success">paid</span>
                                                    </td>
                                                <?php else: ?>
                                                    <td class=""><span class="badge bg-label-danger">unpaid</span>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Invoice table -->
            </div>
            <!--/ User Content -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\laragon\www\PMS\resources\views/user/viewProject.blade.php ENDPATH**/ ?>