
<?php $__env->startSection('userContent'); ?>
    <!-- =============== Design & Develop By = MJ MARAZ   ====================== -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center bold-taxt " style=""> Project Listes</h1>
                <div class="data_table">
                    <table id="example" class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Project Name</th>
                                <th>Payment Status(Last Month)</th>
                                <th>Project Status</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $ProjectData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('viewProjectData', $item->id)); ?>"><?php echo e($item->ProjectName); ?></a>
                                    </td>
                                    <?php if($item->status === 'Active'): ?>
                                        <td class=""><span class="badge bg-label-danger">paid</span>
                                        </td>
                                    <?php else: ?>
                                        <td class=""><span class="badge bg-label-success">unpaid</span>
                                        </td>
                                    <?php endif; ?>

                                    <?php if($item->status === 'Active'): ?>
                                        <td class=""><span class="badge bg-label-success"><?php echo e($item->status); ?></span>
                                        </td>
                                    <?php else: ?>
                                        <td class=""><span class="badge bg-label-danger"><?php echo e($item->status); ?></span>
                                        </td>
                                    <?php endif; ?>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\laragon\www\PMS\resources\views/user/allProjectData.blade.php ENDPATH**/ ?>