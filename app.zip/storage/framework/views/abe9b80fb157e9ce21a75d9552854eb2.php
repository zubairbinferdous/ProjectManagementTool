<!DOCTYPE html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed" dir="ltr" data-theme="theme-default"
    data-assets-path="../../assets/" data-template="vertical-menu-template-no-customizer">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Dashboard User</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/assets/img/favicon/favicon.ico')); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="<?php echo e(asset('https://fonts.googleapis.com')); ?>" />
    <link rel="preconnect" href="<?php echo e(asset('https://fonts.gstatic.com')); ?>" crossorigin />
    <link
        href="<?php echo e(asset('https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap')); ?>"
        rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/fonts/fontawesome.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/fonts/tabler-icons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/fonts/flag-icons.css')); ?>" />

    
    <link rel="stylesheet" href="<?php echo e(asset('userAssets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('userAssets/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('userAssets/css/style.css')); ?>">




    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/css/rtl/core.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/css/rtl/theme-default.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/css/demo.css')); ?>" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/node-waves/node-waves.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/typeahead-js/typeahead.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/apex-charts/apex-charts.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/swiper/swiper.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/node-waves/node-waves.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/typeahead-js/typeahead.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/flatpickr/flatpickr.css')); ?>" />
    <!-- Row Group CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/datatables-rowgroup-bs5/rowgroup.bootstrap5.css')); ?>" />
    <!-- Form Validation -->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/libs/formvalidation/dist/css/formValidation.min.css')); ?>" />

    <!-- Page CSS -->
    <link rel="stylesheet" href="/assets/vendor/css/pages/cards-advance.css" />
    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
</head>



<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar layout-without-menu">
        <div class="layout-container">
            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                    id="layout-navbar">
                    <div class="avatar ">
                        <a class="" href="<?php echo e(url('/dashboard')); ?>"> <img src="../../assets/img/avatars/logo.jpg"
                                alt class="h-auto rounded-circle" />
                        </a>
                    </div>
                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">





                        <h5 class="header-data-area">LKSS HUMAN RESOURCE CENTER (LKSS-HRC)</h5>

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="../../assets/img/avatars/1.png" alt class="h-auto rounded-circle" />
                                    </div>
                                </a>



                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="../../assets/img/avatars/1.png" alt
                                                            class="h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-semibold d-block"><?php echo e(Auth::User()->name); ?></span>
                                                    <small class="text-muted"><?php echo e(Auth::User()->email); ?></small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li style="">
                                        <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                            <i class="ti ti-user-check me-2 ti-sm"></i>
                                            <span class="align-middle">Profile Page</span>
                                        </a>
                                    </li>

                                    <li style="padding-bottom: 20px">
                                        <a class="dropdown-item" href="<?php echo e(url('/dashboard')); ?>">
                                            <i class="ti ti-user-check me-2 ti-sm"></i>
                                            <span class="align-middle">Home Page</span>
                                        </a>
                                    </li>

                                    <li>
                                        <div class="d-flex justify-content-center align-items-center">
                                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="btn rounded-pill btn-danger waves-effect waves-light test-center">
                                                    <i class="ti ti-logout me-2 ti-sm"></i>
                                                    <span class="align-middle">Log Out</span></button>

                                            </form>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>

                    </div>

                    <!-- Search Small Screens -->
                    
                </nav>
                <!-- / Navbar -->
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <?php echo $__env->yieldContent('userContent'); ?>
                    
                    <!-- / Content -->

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">

                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>
    </div>
    <!-- / Layout wrapper -->

    


    
    
    <script src="<?php echo e(asset('/userAssets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/userAssets/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/userAssets/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('/userAssets/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/userAssets/js/custom.js')); ?>"></script>


    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(asset('/assets/vendor/libs/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/node-waves/node-waves.js')); ?>"></script>

    <script src="<?php echo e(asset('/assets/vendor/libs/hammer/hammer.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/i18n/i18n.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/typeahead-js/typeahead.js')); ?>"></script>

    <script src="<?php echo e(asset('/assets/vendor/js/menu.js')); ?>"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?php echo e(asset('/assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/swiper/swiper.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-responsive/datatables.responsive.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.js')); ?>"></script>

    <script src="<?php echo e(asset('/assets/vendor/libs/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-responsive/datatables.responsive.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-buttons/datatables-buttons.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/jszip/jszip.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/pdfmake/pdfmake.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-buttons/buttons.html5.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-buttons/buttons.print.js')); ?>"></script>
    <!-- Flat Picker -->
    <script src="<?php echo e(asset('/assets/vendor/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/flatpickr/flatpickr.js')); ?>"></script>
    <!-- Row Group JS -->
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-rowgroup/datatables.rowgroup.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/libs/datatables-rowgroup-bs5/rowgroup.bootstrap5.js')); ?>"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('/assets/js/main.js')); ?>"></script>

    <!-- Page JS -->
    <script src="<?php echo e(asset('/assets/js/dashboards-analytics.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\laragon\laragon\www\PMS\resources\views/userIndex.blade.php ENDPATH**/ ?>