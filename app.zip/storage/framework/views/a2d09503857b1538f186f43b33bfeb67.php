
<?php $__env->startSection('userContent'); ?>
    <!-- =============== Design & Develop By = MJ MARAZ   ====================== -->
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center bold-taxt " style=""> Employee Listes</h1>
                <div class="data_table">
                    <table id="example" class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>NID</th>
                                <th>Project Name</th>
                                <th>Last Month Payment</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $EmployeeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('viewEmployee', $item->id)); ?>"><?php echo e($item->EmployeeName); ?></a></td>
                                    <td><?php echo e($item->PhoneNumber); ?></td>
                                    <td><?php echo e($item->NidNumber); ?></td>
                                    <td><?php echo e($item->projectData->ProjectName); ?></td>
                                    <td class=""><span class="badge bg-label-danger">unpaid</span>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\laragon\www\PMS\resources\views/user/allEmployeeData.blade.php ENDPATH**/ ?>