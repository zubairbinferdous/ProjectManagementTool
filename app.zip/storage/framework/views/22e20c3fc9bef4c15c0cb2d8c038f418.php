
<?php $__env->startSection('content'); ?>
    <div class="authentication-inner py-4">
        <!-- Register Card -->
        <div class="card">
            <div class="card-body">
                <!-- Logo -->
                
                <!-- /Logo -->
                <h4 class="mb-1 pt-2">Add User Area🚀</h4>


                <form id="formAuthentication" class="mb-3 fv-plugins-bootstrap5 fv-plugins-framework" method="POST"
                    action="<?php echo e(route('registerUserData')); ?>" novalidate="novalidate">

                    <?php echo csrf_field(); ?>
                    <div class="mb-3 fv-plugins-icon-container">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="name"
                            placeholder="Enter your username" autofocus="">
                        <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>
                    <div class="mb-3 fv-plugins-icon-container">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email" name="email"
                            placeholder="Enter your email">
                        <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>
                    <div class="mb-3 form-password-toggle fv-plugins-icon-container">
                        <label class="form-label" for="password">Password</label>
                        <div class="input-group input-group-merge has-validation">
                            <input type="password" id="password" class="form-control" name="password"
                                placeholder="············" aria-describedby="password">
                            <span class="input-group-text cursor-pointer"><i class="ti ti-eye-off"></i></span>
                        </div>
                        <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>
                    <div class="mb-3 form-password-toggle fv-plugins-icon-container">
                        <label class="form-label" for="password">Confirm Password</label>
                        <div class="input-group input-group-merge has-validation">
                            <input type="password" id="password" class="form-control" name="password_confirmation"
                                placeholder="············" aria-describedby="password">
                            <span class="input-group-text cursor-pointer"><i class="ti ti-eye-off"></i></span>
                        </div>
                        <div class="fv-plugins-message-container invalid-feedback"></div>
                    </div>

                    
                    <button class="btn btn-primary d-grid w-100 waves-effect waves-light">Sign up</button>
                    <input type="hidden">
                </form>

                

                
            </div>
        </div>
        <!-- Register Card -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\laragon\www\PMS\resources\views/addUser/adduser.blade.php ENDPATH**/ ?>